# WGS / WES Variant Calling Pipeline

A Snakemake pipeline for germline variant calling from paired-end Illumina data.
Works for **plant, animal, and human** samples, in either **whole-genome (WGS)** or
**exome / targeted (WES)** mode, with **optional BQSR**.

Everything is driven by `config_wgs.yaml` — the same Snakefile handles all
combinations without editing rules.

---

## Contents

| File | Purpose |
|---|---|
| `Snakefile_WGS` | The pipeline |
| `config_wgs.yaml` | All settings (reference, mode switches, filters, tools) |
| `samples_wgs.tsv` | Sample sheet — one row per sample |
| `environment.yml` | Conda environment definition |

---

## 1. Installation

```bash
conda env create -f environment.yml
conda activate wgs_wes
```

Or create the environment directly:

```bash
conda create -n wgs_wes -c conda-forge -c bioconda \
    snakemake-minimal pandas fastqc seqkit fastp bwa samtools \
    htslib gatk4 bcftools mosdepth multiqc
conda activate wgs_wes
```

All tools resolve from the active environment's `$PATH`. You only need to set a
path in `config_wgs.yaml` → `tools:` if a tool lives outside the environment.

### Tools used

| Tool | Step |
|---|---|
| fastqc, seqkit | QC before and after trimming |
| fastp | Adapter/quality trimming |
| bwa, samtools | Alignment, sorting, indexing, BAM stats |
| gatk4 | MarkDuplicates, BQSR, HaplotypeCaller, filtering |
| mosdepth | Target coverage QC (exome mode) |
| bcftools, htslib | VCF utilities (contig renaming, indexing) |
| multiqc | Optional QC aggregation |

---

## 2. Reference preparation (one time, per reference)

The pipeline does **not** build reference indexes. Prepare them first:

```bash
bwa index reference/genome.fna
samtools faidx reference/genome.fna
gatk CreateSequenceDictionary -R reference/genome.fna
```

---

## 3. Sample sheet

`samples_wgs.tsv` — tab-separated, one row per sample:

```
sample	read1	read2
S01	raw/Prameela_S250_L008_R1_001.fastq.gz	raw/Prameela_S250_L008_R2_001.fastq.gz
S02	raw/Ankit_L001_R1.fastq.gz	raw/Ankit_L001_R2.fastq.gz
S03	raw/millet24_R1.fq.gz	raw/millet24_R2.fq.gz
```

- The `sample` column becomes the **output folder name** — use clean names
  (no spaces, slashes, or dots).
- FASTQ filenames can be anything; they do not need to match the sample name.
- Add as many rows as you like. Snakemake parallelises across samples
  automatically according to `--cores`.

---

## 4. Configuration

All behaviour is set in `config_wgs.yaml`.

### Run modes

Two independent switches control the mode:

| | `capture.targets` | `bqsr.run` | Typical use |
|---|---|---|---|
| Plant / animal WGS | `""` | `false` | Millet, crop, non-model organism |
| Plant / animal exome | path to BED/interval_list | `false` | Targeted capture, non-model |
| Human WGS | `""` | `true` | Human whole genome |
| Human exome | path to BED/interval_list | `true` | Clinical WES |

**`capture.targets`**
- Leave empty (`""`) → **WGS mode**: variants called genome-wide, no coverage QC.
- Set to a BED or Picard `.interval_list` → **EXOME mode**: BQSR and variant
  calling are restricted to the targets plus `capture.padding` bp, and mosdepth
  target-coverage QC is produced.

**`bqsr.run`**
- `false` → BQSR skipped entirely. Correct for organisms without known-sites
  resources (most plants and animals).
- `true` → requires one or more known-sites VCFs under `bqsr.known_sites`
  (bgzipped and tabix-indexed). Standard human set: dbSNP + Mills +
  known-indels.

### Hard-filter thresholds

`filters:` holds the GATK hard-filter cutoffs for SNPs and indels separately,
plus genotype-level DP/GQ thresholds. Defaults follow GATK Best Practices.

### Check the resolved mode before running

```bash
snakemake -s Snakefile_WGS --cores 1 --config help=true
```

Prints the current mode, target file, BQSR status, and output directory.

---

## 5. Running

Dry run first — validates the job graph without executing anything:

```bash
snakemake -s Snakefile_WGS -n --cores 32
```

Real run:

```bash
snakemake -s Snakefile_WGS --cores 32 -p
```

Useful flags:

| Flag | Effect |
|---|---|
| `-n` | Dry run |
| `-p` | Print each shell command as it executes |
| `--cores N` | Max cores across all concurrent jobs |
| `--keep-going` | Continue other samples if one fails |
| `--rerun-incomplete` | Redo jobs left incomplete by an interrupted run |
| `--config outdir=my_results` | Override output directory |

To capture the full console output of a run:

```bash
snakemake -s Snakefile_WGS --cores 32 -p 2>&1 | tee run_$(date +%Y%m%d_%H%M%S).log
```

---

## 6. Output structure

Each sample gets its own folder containing the complete analysis tree:

```
results_wgs/
└── <sample>/
    ├── qc_raw/
    │   ├── fastqc/         <sample>_1_fastqc.html, _2_fastqc.html
    │   └── seqkit/         <sample>.txt
    ├── trimmed_reads/      <sample>_1_trimmed.fastq.gz, _2_trimmed.fastq.gz
    ├── qc_trimmed/
    │   ├── fastqc/
    │   └── seqkit/
    ├── aligned/
    │   ├── <sample>.bam            (duplicate-marked, indexed)
    │   ├── <sample>_recal.table    (BQSR mode)
    │   └── <sample>_bqsr.bam       (BQSR mode)
    ├── coverage/                   (exome mode only)
    │   ├── <sample>.mosdepth.summary.txt
    │   ├── <sample>.regions.bed.gz
    │   └── <sample>.thresholds.bed.gz
    ├── variant_calling/
    │   ├── gvcf/           <sample>.g.vcf.gz
    │   ├── genotyped/      <sample>.vcf.gz
    │   ├── snps/           _SNPs_raw / _SNPs_filtered / _SNPs_PASS .vcf.gz
    │   └── indels/         _INDELs_raw / _INDELs_filtered / _INDELs_PASS .vcf.gz
    └── logs/
        ├── timer/          <sample>_start.txt, <sample>_runtime.txt
        ├── seqkit_before/  fastqc_before/  fastp/
        ├── fastqc_after/   seqkit_after/   bwa/
        ├── bam_stats/      <sample>.txt   (samtools stats)
        ├── mosdepth/       (exome mode)
        └── gatk/           per-step logs + <sample>_dup_metrics.txt
```

**Final deliverables** are `variant_calling/snps/<sample>_SNPs_PASS.vcf.gz` and
`variant_calling/indels/<sample>_INDELs_PASS.vcf.gz`.

All directories are created automatically. Note that per-step logs are
**overwritten** when a rule is re-run; Snakemake's own per-invocation log is
written to `.snakemake/log/` with a timestamp.

---

## 7. Pipeline steps

| # | Step | Tool | Notes |
|---|---|---|---|
| 1 | Raw read stats | seqkit | |
| 2 | Raw QC | FastQC | Output renamed to `<sample>_1/_2` |
| 3 | Trimming | fastp | Adapter auto-detection, poly-G trim |
| 4 | Post-trim QC | FastQC | |
| 5 | Post-trim stats | seqkit | |
| 6 | Alignment + sort | bwa mem \| samtools sort | Read group added inline; no intermediate SAM |
| 7 | Mark duplicates | GATK MarkDuplicates | Indexed afterwards |
| 8 | BAM stats | samtools stats | |
| 8b | Target coverage | mosdepth | Exome mode only; thresholds 1/10/20/30× |
| 9 | BQSR | GATK BaseRecalibrator + ApplyBQSR | Optional; on-target when in exome mode |
| 10 | Variant calling | GATK HaplotypeCaller | GVCF mode (`-ERC GVCF`) |
| 11 | Genotyping | GATK GenotypeGVCFs | Per sample |
| 12–14 | SNPs: select → filter → PASS | GATK | |
| 15–17 | Indels: select → filter → PASS | GATK | |

---

## 8. Notes and gotchas

**Contig naming must match everywhere.** The reference, target BED/interval_list,
and known-sites VCFs must all use the same contig names. Mixing NCBI RefSeq
(`NC_000001.11`) with UCSC/Broad (`chr1`) causes GATK contig-mismatch errors, or
silently produces zero coverage. To convert:

```bash
# VCF
bcftools annotate --rename-chrs map.txt in.vcf.gz -Oz -o out.vcf.gz
tabix -p vcf out.vcf.gz

# BED (map.txt = two columns: old_name <TAB> new_name)
awk 'BEGIN{FS=OFS="\t"} NR==FNR{m[$1]=$2; next} ($1 in m){$1=m[$1]; print}' \
    map.txt in.bed | sort -k1,1 -k2,2n > out.bed
```

**Prefer `.interval_list` over raw BED.** GATK can reject otherwise valid BED
files with `Badly formed genome unclippedLoc / Query interval ... is not valid`.
Convert once:

```bash
gatk BedToIntervalList -I targets.bed -SD reference/genome.dict -O targets.interval_list
```

This also validates every interval against the sequence dictionary.

**Hard filtering, not VQSR.** This pipeline uses GATK hard filters, which is the
correct choice for single samples and small cohorts. VQSR requires roughly 30+
exomes to train reliably and is not included.

**Genotype-level DP/GQ filters.** These populate the per-sample `FT` field only;
they do not change the site-level `FILTER` column, so `--exclude-filtered` does
not remove them. To drop those genotypes as well, add
`--set-filtered-genotype-to-no-call` to the `VariantFiltration` rules.

**Per-sample calling.** Each sample is genotyped independently. For a
trio/family, joint genotyping (`GenomicsDBImport` → `GenotypeGVCFs`) gives better
genotype refinement — the GVCFs produced here are compatible with that workflow.

**Threads.** `threads:` in the config sets per-rule threads. GATK
BaseRecalibrator/ApplyBQSR are single-threaded by design (no thread option
exists); HaplotypeCaller uses `--native-pair-hmm-threads`, which scales well up
to roughly 16 threads.

---

## 9. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `Query interval ... is not valid` | Convert the BED to `.interval_list` with `BedToIntervalList` |
| `Input files ... have incompatible contigs` | Contig naming mismatch between reference, targets, and known-sites |
| `bqsr.run is true but no known_sites provided` | Add VCFs under `bqsr.known_sites`, or set `run: false` |
| mosdepth reports zero coverage | Target BED contig names don't match the BAM header |
| `MissingOutputException` on FastQC | Should not occur — outputs are renamed automatically; check the FastQC log |
| Warnings about `MQRankSum` / `ReadPosRankSum` | Expected — those annotations only exist at heterozygous sites |
| Interrupted run won't restart | `snakemake -s Snakefile_WGS --cores 32 --rerun-incomplete` |

Per-step logs live in `results_wgs/<sample>/logs/<step>/`. Check the log for the
specific failing rule and sample first.
